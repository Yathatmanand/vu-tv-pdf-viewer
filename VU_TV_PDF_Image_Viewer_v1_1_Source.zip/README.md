# TV PDF & Image Viewer 1.1

Android TV-oriented source project for a remote-friendly PDF and image viewer.

## Included
- Android TV / Leanback launcher entry
- Android Storage Access Framework picker for USB and shared/internal storage
- PDF rendering using Android PdfRenderer
- JPG and PNG image viewing
- Remote-friendly buttons: Open, Previous/Next, Zoom In/Out, Fit, Bookmark, Go to Page
- Saves last opened document and last PDF page
- Landscape full-screen interface

## Build APK
1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 when prompted.
3. Sync Gradle.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Install on VU TV
Copy the APK to a USB drive, open it using a TV file manager, and allow installation from that source if Android asks. The TV firmware may restrict sideloading.

## Important
This is a source project, not a prebuilt APK. It has not been compiled or tested on the VU 50VIBE-DV hardware in this environment. USB visibility is controlled by the Android document picker supplied by the TV firmware. Very large image files may use substantial memory on TVs with 2 GB RAM.
